Copie a pasta ui sobre a existente.
