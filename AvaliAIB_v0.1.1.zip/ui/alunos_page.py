from PySide6.QtWidgets import QWidget,QVBoxLayout,QLabel
class AlunosPage(QWidget):
    def __init__(self):
        super().__init__();l=QVBoxLayout(self);l.addWidget(QLabel('Página de alunos (próxima versão: CRUD)'))
