import sys
from PySide6.QtWidgets import QApplication,QMainWindow,QTabWidget
from ui.dashboard import Dashboard
from ui.turmas_page import TurmasPage
from ui.alunos_page import AlunosPage
class Main(QMainWindow):
    def __init__(self):
        super().__init__();tabs=QTabWidget();tabs.addTab(Dashboard(),'Dashboard');tabs.addTab(TurmasPage(),'Turmas');tabs.addTab(AlunosPage(),'Alunos');self.setCentralWidget(tabs)
def run():
 app=QApplication(sys.argv);w=Main();w.show();app.exec()
