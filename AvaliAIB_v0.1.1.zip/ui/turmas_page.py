from PySide6.QtWidgets import QWidget,QVBoxLayout,QListWidget
class TurmasPage(QWidget):
    def __init__(self):
        super().__init__();l=QVBoxLayout(self);w=QListWidget();[w.addItem(t) for t in ['12A','12A1','12B','12B1','12C','12C1']];l.addWidget(w)
